Akita is a jQuery based plygin that creates a speech bubble tooltip base on the specified options
Requires jQuery 1.5 and above
Released under the MIT license and anyone can use and modify without any restriction
Developed by Paul Yuan, http://www.paulyuan.ca

======================================================
CHANGE LOG:
======================================================
v1.1.2 (2014.10.13)
- fixed typo for "respositionAll", should be "repositionAll"

v1.1.1 (2013.05.27)
-removed pointer-events:none property so user can interact with tooltips

v1.1 (2012.08.12)
-repositioning of speech bubbles on window scroll & resize events
-added option to specify placement of speech bubble
-fix for speech bubbles not properly being hidden on hide event
-fix for speech bubble blocking mouse interaction with element behind it
 
