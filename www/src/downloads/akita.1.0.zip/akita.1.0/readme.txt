Akita is a jQuery based plygin that creates a speech bubble tooltip base on the specified options
Requires jQuery 1.5 and above
Released under the MIT license and anyone can use and modify without any restriction
Developed by Paul Yuan, http://www.paulyuan.ca